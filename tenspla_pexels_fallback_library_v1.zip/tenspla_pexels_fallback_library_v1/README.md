# Tens Pla? Generic Image Library V1

Curated manifest of **100 generic Pexels photos**, 10 per Tens Pla? category:

- festes
- musica
- fires-mercats
- gastronomia
- familia
- espectacles
- cultura
- museus
- patrimoni
- natura

## What is included

- `fallback-images.json`: exact Pexels photo IDs, source pages, photographers, local target filenames, CA/ES alt text and provenance policy.
- `resolver-guidance.json`: deterministic category selection guidance and keyword hints.

**The Pexels binary image files are not bundled in this package.** The manifest is intentionally the source-of-truth selection artifact. During implementation, download each selected photo once from its `source_page`, optimize it to local WebP, and serve it from Tens Pla?. Do not call Pexels at runtime.

## Recommended ingestion

1. Review/download each selected photo from its exact `source_page`.
2. Keep the original Pexels photo ID + photographer + source page in versioned provenance metadata.
3. Convert to WebP, target ~1600 px master width, quality around 82; inspect crop behavior before committing.
4. Store under a local path matching `local_filename`.
5. Resolve a fallback image deterministically from `plan.fingerprint` within the resolved category.
6. Never write a generic fallback into the source's official `image_url` field. Return/display it as a separate `generic` image kind.
7. In plan detail, show `Imatge orientativa` / `Imagen orientativa` for generic images.
8. Do **not** expose generic fallback photos as `Event.image` in JSON-LD.

## Legal/provenance note

The selection was made from Pexels pages marked free to use under the Pexels License. Pexels attribution is not required by the standard license, although attribution is appreciated. Keep provenance anyway. Before production ingestion, retain the exact source page and license URL so the selection remains auditable. Avoid implying that people, places, brands, artworks or properties shown endorse Tens Pla? or are the event itself.

License: https://www.pexels.com/license/

Selected: 2026-08-29
